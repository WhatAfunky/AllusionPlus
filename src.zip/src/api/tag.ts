import { ID } from './id';

export const ROOT_TAG_ID = 'root';
export const ROOT_LOCATIONS_TAG_ID = 'locations_root';

export type TagDTO = {
  id: ID;
  name: string;
  dateAdded: Date;
  color: string;
  subTags: ID[];
  impliedTags: ID[];
  /** Whether any files with this tag should be hidden */
  isHidden: boolean;
  /** Whether a tag is marked as Visible when inherited */
  isVisibleInherited: boolean;
  isHeader: boolean;
  aliases: string[];
  description: string;
  fileCount: number;
  isFileCountDirty: boolean;
};
