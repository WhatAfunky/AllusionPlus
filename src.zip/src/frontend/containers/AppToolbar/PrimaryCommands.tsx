import { observer } from 'mobx-react-lite';
import React from 'react';

import { IconSet } from 'widgets';
import { ToolbarButton } from 'widgets/toolbar';
import { FileRemoval } from '../../components/RemovalAlert';
import { useStore } from '../../contexts/StoreContext';
import { SortCommand, ViewCommand } from './Menus';
import Searchbar from './Searchbar';
import {
  FileExifEditorButton,
  FileExtraPropertiesEditorButton,
  FileTagEditorButton,
  InspectorButton,
} from './ToolbarButtons';

const OutlinerToggle = observer(() => {
  const { uiStore } = useStore();

  return (
    <ToolbarButton
      id="outliner-toggle"
      text="Toggle Outliner"
      icon={uiStore.isOutlinerOpen ? IconSet.DOUBLE_CARET : IconSet.MENU_HAMBURGER}
      controls="outliner"
      pressed={uiStore.isOutlinerOpen}
      onClick={uiStore.toggleOutliner}
      tabIndex={0}
    />
  );
});

const PrimaryCommands = observer(() => {
  const { fileStore } = useStore();

  return (
    <>
      <OutlinerToggle />
      <FileSelectionCommand />

      <Searchbar />

      {/* TODO: Put back tag button (or just the T hotkey) */}
      {fileStore.showsMissingContent ? (
        // Only show option to remove selected files in toolbar when viewing missing files */}
        <RemoveFilesPopover />
      ) : (
        // Only show when not viewing missing files (so it is replaced by the Delete button)
        //<div className="expandable-button-list">
        <>
          <FileTagEditorButton />
          <FileExtraPropertiesEditorButton />
          <FileExifEditorButton />
          <InspectorButton />
        </>
        //</div>
      )}

      <SortCommand />

      <ViewCommand />
    </>
  );
});

export default PrimaryCommands;

export const SlideModeCommand = () => {
  const { uiStore } = useStore();
  return (
    <>
      <ToolbarButton
        isCollapsible={false}
        icon={IconSet.ARROW_LEFT}
        onClick={uiStore.disableSlideMode}
        text="Back"
        tooltip="Back to content panel"
      />

      <div className="spacer" />

      <FileTagEditorButton />
      <FileExtraPropertiesEditorButton />
      <FileExifEditorButton />

      <InspectorButton />
    </>
  );
};

const FileSelectionCommand = observer(() => {
  const { uiStore, fileStore } = useStore();
  const fileLoadedCount = fileStore.numLoadedFiles;
  const fileCount = fileStore.showsMissingContent ? fileLoadedCount : fileStore.numFilteredFiles;
  const allFilesSelected = uiStore.isAllFilesSelected;
  const selectionCount = allFilesSelected ? fileCount : uiStore.fileSelection.size;

  // If everything is selected, deselect all. Else, select all
  const handleToggleSelect = () => {
    allFilesSelected ? uiStore.clearFileSelection() : uiStore.selectAllFiles();
  };

  return (
    <ToolbarButton
      isCollapsible={false}
      icon={allFilesSelected ? IconSet.SELECT_ALL_CHECKED : IconSet.SELECT_ALL}
      onClick={handleToggleSelect}
      pressed={allFilesSelected}
      text={fileCount == 0 ? '0' : selectionCount + ' / ' + fileCount}
      tooltip={`Selects or deselects all images, (${fileLoadedCount} loaded files)`}
      disabled={fileCount === 0}
    />
  );
});

const RemoveFilesPopover = observer(() => {
  const { uiStore } = useStore();
  return (
    <>
      <ToolbarButton
        icon={IconSet.DELETE}
        disabled={uiStore.fileSelection.size === 0}
        onClick={uiStore.openToolbarFileRemover}
        text="Delete"
        tooltip="Delete selected missing images from library"
      />
      <FileRemoval />
    </>
  );
});
