import { action, computed, makeObservable, observable } from 'mobx';
import { DataStorage } from '../../api/data-storage';
import { ExtraPropertyDTO, ExtraPropertyType, ExtraPropertyValue } from '../../api/extraProperty';
import { generateId, ID } from '../../api/id';
import { ClientExtraProperty } from '../entities/ExtraProperty';
import RootStore from './RootStore';
import { ClientFile } from '../entities/File';

class ExtraPropertyStore {
  private readonly backend: DataStorage;
  private readonly rootStore: RootStore;

  private readonly extraPropertiesMap = observable(new Map<ID, ClientExtraProperty>());

  constructor(backend: DataStorage, rootStore: RootStore) {
    this.backend = backend;
    this.rootStore = rootStore;

    makeObservable(this);
  }

  async init(): Promise<void> {
    try {
      const fetchedExtraProperties = await this.backend.fetchExtraProperties();
      for (const sp of fetchedExtraProperties) {
        const extraProperty = new ClientExtraProperty(this, sp.id, sp.type, sp.name, sp.dateAdded);
        this.extraPropertiesMap.set(extraProperty.id, extraProperty);
      }
    } catch (err) {
      console.log('Could not load extraProperties', err);
    }
  }

  @action get(id: string): ClientExtraProperty | undefined {
    return this.extraPropertiesMap.get(id);
  }

  @action getByNameAndType(name: string, type: ExtraPropertyType): ClientExtraProperty | undefined {
    for (const [, extraProperty] of this.extraPropertiesMap) {
      if (extraProperty.name === name && extraProperty.type === type) {
        return extraProperty;
      }
    }
    return undefined;
  }

  // Returns true if already exists an extraa property with the same name
  @action exists(name: string): boolean {
    for (const [, extraProperty] of this.extraPropertiesMap) {
      if (extraProperty.name === name) {
        return true;
      }
    }
    return false;
  }

  @computed get extraPropertiesList(): readonly ClientExtraProperty[] {
    return Array.from(this.extraPropertiesMap.values()).sort((a, b) =>
      a.name.localeCompare(b.name),
    );
  }

  @computed get count(): number {
    return this.extraPropertiesMap.size;
  }

  @computed get isEmpty(): boolean {
    return this.count === 0;
  }

  @action.bound async createExtraProperty(
    propertyName: string,
    type: ExtraPropertyType,
  ): Promise<ClientExtraProperty> {
    const id = generateId();
    const extraProperty = new ClientExtraProperty(this, id, type, propertyName, new Date());
    this.extraPropertiesMap.set(extraProperty.id, extraProperty);
    await this.backend.createExtraProperty(extraProperty.serialize());
    return extraProperty;
  }

  @action.bound async deleteExtraProperty(extraProperty: ClientExtraProperty): Promise<void> {
    this.extraPropertiesMap.delete(extraProperty.id);
    extraProperty.dispose();
    await this.backend.removeExtraProperties([extraProperty.id]);
    this.rootStore.fileStore.refetch();
  }

  @action.bound removeFromFiles(files: ClientFile[], extraProperty: ClientExtraProperty): void {
    files.forEach((f) => f.removeExtraProperty(extraProperty));
  }

  @action.bound async dispatchOnFiles(
    files: ClientFile[],
    extraProperty: ClientExtraProperty,
    value?: ExtraPropertyValue,
    overwrite: boolean = true,
  ): Promise<void> {
    const dispatch = async (batchFiles: ClientFile[]) => {
      batchFiles.forEach((f) => {
        if (overwrite || !f.extraProperties.has(extraProperty)) {
          f.setExtraProperty(extraProperty, value);
        }
      });
    };
    const isAllFilesSelected = this.rootStore.uiStore.isAllFilesSelected;
    await dispatch(Array.from(files));
    if (isAllFilesSelected) {
      await this.rootStore.fileStore.dispatchToFilteredFiles(dispatch);
    }
  }

  save(extraProperty: ExtraPropertyDTO): void {
    this.backend.saveExtraProperty(extraProperty);
  }
}

export default ExtraPropertyStore;
